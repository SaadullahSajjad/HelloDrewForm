(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_page_588c1a.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_page_588c1a.js",
  "chunks": [
    "static/chunks/node_modules_72c49c._.js",
    "static/chunks/src_app_fed6e4._.js",
    "static/chunks/_ea5bfa._.css"
  ],
  "source": "dynamic"
});
