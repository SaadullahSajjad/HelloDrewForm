(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_secretpage_page_588c1a.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_secretpage_page_588c1a.js",
  "chunks": [
    "static/chunks/node_modules_antd_es_f9699d._.js",
    "static/chunks/node_modules_@ant-design_cssinjs_es_639ffb._.js",
    "static/chunks/node_modules_rc-field-form_es_4fb5d7._.js",
    "static/chunks/node_modules_rc-tabs_es_eb5572._.js",
    "static/chunks/node_modules_rc-menu_es_657c33._.js",
    "static/chunks/node_modules_03080f._.js",
    "static/chunks/src_app_secretpage_page_0705fa.js"
  ],
  "source": "dynamic"
});
