(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_talkpage_page_588c1a.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_talkpage_page_588c1a.js",
  "chunks": [
    "static/chunks/node_modules_antd_es_de8293._.js",
    "static/chunks/node_modules_@ant-design_cssinjs_es_639ffb._.js",
    "static/chunks/node_modules_rc-field-form_es_4fb5d7._.js",
    "static/chunks/node_modules_b7bc0c._.js",
    "static/chunks/src_app_talkpage_page_4b4a09.js"
  ],
  "source": "dynamic"
});
